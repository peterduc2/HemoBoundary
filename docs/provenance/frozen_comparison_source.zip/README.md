# HemoBoundary V8: published-method comparison with explicit adaptations

## What this package does

This is an executable benchmark, not a declaration that every method is an exact
reproduction or that HemoBoundary is state of the art. It runs the stated
implementations on the original controlled HemoBoundary tasks. Do not remove the
implementation qualifiers when using its results in a manuscript.

The default run covers SHIN internal participant holdout plus Bálint and Khan
external evaluation. It reads the final strict HemoBoundary predictions; it never
trains HemoBoundary, changes its predictions or writes over its old experiments.

A complete run contains **770 dataset-seed-participant cases**: 260 Shin, 260
Bálint and 250 Khan. These are **26, 26 and 25 participants**, not 770 independent
people. Ten seeds are repeated source simulations/fits.

## Run in Google Colab

Open `HEMOBOUNDARY_V8_FULL_COLAB.ipynb` and run its single code cell. The cell embeds
this complete package, mounts Drive if necessary, builds an isolated environment,
runs software tests and launches the full benchmark. It does not upgrade NumPy or
pandas inside the active Colab kernel. `RUN_MODE = "full"` is the default.

The equivalent standalone bundle is `HEMOBOUNDARY_V8_FULL_SINGLE_FILE.py`. Upload
it to Colab, then execute:

```python
%run /content/HEMOBOUNDARY_V8_FULL_SINGLE_FILE.py --mode full
```

The multi-file source package can also be run with:

```bash
python run_colab.py --mode full
```

`--mode pilot` runs VP001 and the first participant from each external dataset
using all 26 source banks. `--mode seed1` evaluates the first seed across all
participants. `--mode preflight` checks paths, original signal replay, and native
Python interfaces without producing benchmark scores. These modes use the same
fixed method definitions as the full run.

The multichannel AR-IRLS fits and grouped Extra Trees selection are substantially
more expensive than V5. Runtime depends on channels and Colab CPU. No fixed
runtime is promised. Computed waveform estimates and completed participant
predictions are reusable. Re-running after interruption does not change original
inputs or recompute verified, unchanged estimator caches unnecessarily.

## Inputs: paths recovered from the original experiments

Root, with either `/content/gdrive` or `/content/drive` as the mount:

```
MyDrive/HonorProject/shin2018_word_generation_state_preparation_v1/
```

Shin participant-preprocessed inputs are in `02_preprocessed/` with filenames
`VP001_WG_ALIGNED_PREPROCESSED.npz` through `VP026_...npz`.

The original seed-1 bank is under
`95_N4_FUNCTIONAL_ABC_LBR_FULLY_NESTED_10SEEDS_V1/seed_01/fresh_cache/`.
The final seed-1 predictions are under
`98_B0_STRICT_HIERARCHICAL_SEED01_FULLY_NESTED_V1/checkpoints/`.
Seeds 2-10 use the `fresh_cache` and `checkpoints` subfolders of
`99_B0_STRICT_HIERARCHICAL_10SEEDS_V1/seed_##/`.

The external predictions are read ONLY from
`102_OPTIONB_TABLE3_10SEED_BALINT_KHAN_ZERO_SHOT_V1/checkpoints/seed_##_PER_TRIAL.csv.gz`.
The older V95 external analysis is not substituted.

External preprocessing inputs, under `MyDrive/HonorProject/`, are:

```
BALINT_V55_EXTERNAL_PREP/processed/balint_epochs_10hz.h5
KHAN2026_FINGER_HEMOBOUNDARY_EXTERNAL_PREP/processed/khan2026_finger_epochs_10hz.h5
```

The original `102_.../audit/EXTERNAL_FIXED_BANK_QC.csv` is required. The program
does not search the entire Drive. Missing inputs or failed replay checks stop the
run rather than trigger fabricated data, median-signal fallback, or zero padding.

## Original signal replay: why it is necessary

The saved caches do not contain all original HbO/HbR epoch samples. V8 uses the
original recovered data-generation functions and seed namespaces to reconstruct
the same multichannel generated trials, including their original simulated noisy
-5 to 0 s baseline. It validates Shin labels, state features, observations and
other stored arrays against the original cache before admitting the replay.
This is deterministic reconstruction of original cases, not creation of a new
benchmark and not copying true labels into model inputs.

The simulated baselines are **not measured resting segments**. The generator
uses noise profiles estimated from participants' measured recordings. Synthetic
trials contain AR noise, a shared systemic sine, and a generated response. The
original generator does not low-pass filter the complete synthetic trial after
synthesis. Do not confuse preprocessing of the recordings used to estimate noise
profiles with an additional filter on the synthetic response.

For V102 external cases, the original code created the banks in memory. V8 checks
the exact generator, source HDF5, original noise-profile QC, and every saved
reference label across seeds. There is no historical raw external bank hash to
verify. Consequently, external raw-byte equivalence is **not proven**. The audit
records this limitation instead of disguising it as exact historical parity.

The controlled banks have a 0-20 s grid. The approximately 19.9 s limit on real
Khan epochs is a separate real-recording recovery issue; V8 does not extend those
real recordings or use their task markers as true hemodynamic boundary labels.

## Exactly which methods are included

| Identifier | Publication context | What actually runs |
|---|---|---|
| PINTI_AIDE_SEARCH | Pinti et al., 2017, NeuroImage, DOI 10.1016/j.neuroimage.2017.05.001 | Python single-event boxcar/HRF GLM search, CBSI applied per channel, source-calibrated detection threshold. NOT full AIDE iterative event segmentation or MATLAB parity. Detection only. |
| CANONICAL_TD_DD_OLS | Santosa et al., 2019, Neurophotonics, DOI 10.1117/1.NPh.6.2.025009 | Canonical SPM HRF plus temporal and dispersion derivatives, OLS. Basis functions are checked against installed Nilearn. Trial shift/width search is an adaptation. |
| CANONICAL_TD_DD_ARIRLS | AnalyzIR coefficient estimation; Barker et al., 2013; Santosa et al., 2019 | Python forward/backward AR fitting with prefix BIC and leverage-adjusted Tukey IRLS coefficients. Covariance, native t-statistics and the complete AnalyzIR pipeline are not reproduced. MATLAB numerical parity is not established. |
| FIR_SMOOTH | FIR/deconvolution model family considered by Santosa et al., 2019 | Explicit event-lag basis with a second-difference smoothing penalty. The penalty and trial-level readout are benchmark adaptations. |
| HRFUNC_AUTHOR | Schaedig et al., 2026, Neurophotonics, DOI 10.1117/1.NPh.13.S1.S17801 | Actual `hrfunc==1.3.1` API, all recovered channels, original simulated baseline, zero edge expansion, no artificial tail. This single-trial application is not the original scan-level experiment. |
| MAHEUX_PCT20 / MAHEUX_PCT50 | Maheux et al., 2017, Psychophysiology, DOI 10.1111/psyp.12648 | Single-trial percentage-of-peak latency measures at prespecified 20% and 50%. NOT the paper's full jackknife procedure. No recovery results are invented. |
| RIDGE9_CONTROL / EXTRATREES9_CONTROL | Task-matched controls, not SOTA papers | Supervised timing and independent detection using the same nine temporal input features available to HemoBoundary. |

Do not rename a method `official AIDE`, `official Santosa`, or `exact MATLAB port`.
The registry is written to every output directory.

### HRfunc: important mathematical qualification

With a single event impulse and a fully observed response interval, the Toeplitz
normal matrix is identity. The author's scalar ridge then shrinks amplitude by
`1/(1+lambda)` rather than smoothing the waveform. V8 runs the actual package and
checks this identity and time axis against its returned arrays. This makes the
limitation visible. A large boundary error in this setting is NOT evidence that
the authors' continuous-recording HRfunc methodology is generally ineffective.
Treat this as a related-method diagnostic, not the principal SOTA claim.

HRfunc receives unique surrogate channel coordinates only to avoid channel-node
aliasing in its data structure. Coordinates are not anatomical and are not used
for localization, atlas lookup, HRtree transfer or spatial interpolation. The
per-channel analytic check verifies that they do not alter the estimator output.

### Native and supervised boundary readouts

Each waveform family is evaluated in two declared forms, both retained in output:

1. `NATIVE_THRESH`: onset and offset fractions selected independently from source
   participants, with interpolated crossings and peak localization. These are
   additional boundary rules, not native outputs of the cited reconstruction
   papers.
2. `SOURCE_RIDGE_READOUT`: the same fitted curves and common curve features feed
   ridge regressions trained on source boundary labels. Grouped source validation
   chooses the variant and regularization. This gives the alternative methods
   access to supervised boundary information instead of giving HemoBoundary that
   advantage alone. This readout is a NEW adaptation and must be reported as such.

The original simulated peak is the start of a plateau. A conventional observed
maximum is not necessarily the same point. The supervised readout can learn this
operational definition; native peak differences must be interpreted accordingly.

## Separation and evaluation rules

For Shin, the outer participant is excluded from all source fitting and model
selection. Supervised readouts use three grouped source folds; each scaler is fit
only on its corresponding training fold. Detection thresholds are chosen from
source-only scores, with out-of-fold classifier probabilities for the controls.

For Bálint and Khan, models and settings use all 26 Shin source participants and
are frozen for both external datasets. Each external bank is fixed across the ten
source seeds. Test-signal fitting in GLM/deconvolution is legitimate inference;
external boundary labels are never used to choose a fit or setting.

The source calibration grid is frozen in `PROTOCOL.json`. V8 is a new,
post-development benchmark, not a preregistered blind test. Previous pilot
inspection and dataset exposure should be disclosed.

Timing is reported under the frozen HemoBoundary gate to isolate boundary
estimation, and separately under each supported independent detector wrapper.
Shared-gate accuracy is not an independent detection advantage. Percentage
latency methods have only the declared timing output.

Reference-censored cases are excluded from exact offset/duration error, without
using their censor labels to suppress a prediction during estimation. Missing
predictions and finite offsets on censored references are separately visible.
An output's finiteness alone is not proof of observed physiological recovery.

The following scores are kept separate:

- ordinary MAE among valid predictions;
- valid prediction coverage and eligible counts;
- MAE on the same pairwise-valid trials for the candidate and HemoBoundary;
- the historical 4 s missing-prediction loss, plus 2 s and 8 s sensitivity scores.

The missing-prediction loss is NOT ordinary MAE, and finite errors are not clipped
to the penalty. Do not silently substitute it for a conditional MAE column.

## Statistics

Gains are averaged across source seeds within each participant. Participant-level
bootstrap intervals and paired sign-flip Monte Carlo tests are then calculated.
Complete timing contrasts across all requested methods/readouts and datasets form
one Holm family; independent detection forms a separate family. Native and learned
readouts are not selected after looking at external results. Partial runs produce
no full-run inferential claims.

The old R1-R7 adjusted p-values are not incorporated. A table combining those old
contrasts with these new contrasts requires recomputation from the complete raw
p-value family. Seed repeats do not increase the biological sample size. Training
sets overlap between LOSO folds, so the reported participant resampling should be
interpreted as conditional benchmark inference, not independent training-study
replications.

## Outputs and recovery

Default output folder:

```
<Shin root>/HB_V8_MULTICHANNEL_PUBLISHED_COMPARISON/
```

`PROTOCOL.json` fixes code hashes, versions and settings. `METHOD_REGISTRY.json`
records implementation status. `NATIVE_PACKAGE_TESTS.json` reports actual Python
API checks performed in your runtime. `selection_audits/` identifies every source
participant, candidate setting and selected readout. `checkpoints/` contains
per-participant predictions, metrics and content hashes. `PARTICIPANT_METRICS.csv`
and `METHOD_SUMMARY.csv` keep conditional errors and coverage distinct from the
missing-prediction loss. `PAIRED_COMPARISONS.csv` has the declared global correction.
`AUDIT.json` states coverage and limitations.

A changed code version or dependency stack cannot silently resume old results.
Keep an unchanged environment to resume, or use a new output folder for a changed
protocol. The launcher records the resolved dependencies in the environment's
`resolved_requirements.txt`; preserve that file with the exported experiment.

Final table generation can be retried without model fitting:

```bash
python run_colab.py --mode summarize
```

It reads and verifies completed checkpoints. No pandas pivot/reshape is used in
finalization, avoiding the specific Pandas4Warning failure from earlier runs.

## What has and has not been validated

The included tests exercise deterministic Shin replay, external schema and QC
checks, label/identity matching, source exclusion, grouped selection, mathematical
kernel checks, geometry/censoring, failure penalties, hashes/resumption and
participant-level aggregation. They use independent software fixtures, never
presented as experimental findings. Actual HRfunc/Nilearn checks execute in your
Colab environment before the benchmark and abort on failure.

The package has NOT been executed on your mounted Drive here. MATLAB parity and
full original-paper experimental reproduction are NOT established. Running code
successfully does not settle comparator suitability or prove SOTA superiority.
No script can certify every scientific assumption. Use the exact method labels,
inspect all audits and report the remaining adaptations and input limitations.

## Verification status

The development test suite passed **37 tests** on synthetic software fixtures,
including a full original-size training/test-bank workflow and checkpoint reuse.
The exact local package versions and test scope are recorded in
`provenance/VALIDATION_REPORT.json`. These are software tests, not results from
your physiological recordings.

The pinned isolated Colab environment, the actual HRfunc/Nilearn runtime checks,
and the complete 770-case experiment were not executed on your Drive here. The
launcher performs the native-package checks before admitting experimental
results. No MATLAB reference execution was available, so neither the AIDE
search adaptation nor AR-IRLS coefficients are certified as MATLAB-equivalent.
A complete program and passing software tests do not establish that a comparison
is publication-ready without reviewing its data and methodological audits.


### V8 Colab isolated-environment bootstrap correction (14 Oct 2026)

The earlier launcher used Python `venv.EnvBuilder(with_pip=True)`, which
can fail at `ensurepip` on Colab Python 3.13 before any benchmark starts.
The updated launcher uses `with_pip=False` and calls the existing runtime
`python -m pip --python /content/hb_v8_isolated_env/bin/python install -r requirements.txt`.
This installs packages ONLY into the isolated V8 environment, without
changing the active Colab kernel's pandas/NumPy installation. Runtime pip
must support `--python` (pip 22.3+). A previous incomplete environment is
reused safely. The scientific algorithm and evaluation files are unchanged.

If dependency resolution fails, read the pip output; a successful environment
bootstrap does not mean the unexecuted full benchmark has been validated.
